package U5.ENTREGABLE;

public class Comercial extends Local implements mostrarPrecioVenta{
    private String descrip;

    public Comercial(int fecha_construccion, String direccion, int metros, Persona duenio, double precio, String descrip) {
        super(fecha_construccion, direccion, metros, duenio, precio);
        this.descrip = descrip;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    @Override
    public String toString() {
        return "Comercial{" +
                "descrip='" + descrip + '\'' +
                '}';
    }

    @Override
    public void mostrarPrecioVenta() {
        System.out.println("soy una vivienda y valgo"+getPrecio());
    }
}
