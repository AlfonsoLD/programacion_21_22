package U5.ENTREGABLE;

public class EquipamientoServicio extends Propiedad{
    private Tipo tipo;

    public EquipamientoServicio(int fecha_construccion, String direccion, int metros, Tipo tipo) {
        super(fecha_construccion, direccion, metros);
        this.tipo = tipo;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "EquipamientoServicio{" +
                "tipo=" + tipo +
                '}';
    }

}
