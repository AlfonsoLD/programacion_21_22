package U5.ENTREGABLE;

public enum Tipo {
    EDUCATIVO, SANITARIO, DEPORTIVO, OTROS
}
