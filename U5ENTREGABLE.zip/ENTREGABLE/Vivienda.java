package U5.ENTREGABLE;

import java.util.Arrays;

public class Vivienda extends Propiedad implements Comparable<Vivienda>, mostrarPrecioVenta{
    private int numero_banios;
    private int n_habitaciones;
    private int cap_max;
    private double precio;
    private Persona[] lista_personas;

    public Vivienda(int fecha_construccion, String direccion, int metros, int numero_banios, int n_habitaciones, int cap_max, double precio) {
        super(fecha_construccion, direccion, metros);
        this.numero_banios = numero_banios;
        this.n_habitaciones = n_habitaciones;
        this.cap_max = cap_max;
        this.precio = precio;
        lista_personas = new Persona[0];

    }

    public int getNumero_banios() {
        return numero_banios;
    }

    public void setNumero_banios(int numero_banios) {
        this.numero_banios = numero_banios;
    }

    public int getN_habitaciones() {
        return n_habitaciones;
    }

    public void setN_habitaciones(int n_habitaciones) {
        this.n_habitaciones = n_habitaciones;
    }

    public int getCap_max() {
        return cap_max;
    }

    public void setCap_max(int cap_max) {
        this.cap_max = cap_max;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Persona[] getLista_personas() {
        return lista_personas;
    }

    public void setLista_personas(Persona[] lista_personas) {
        this.lista_personas = lista_personas;
    }

    public boolean addPersona(Persona p){
        if(lista_personas.length<cap_max && !esta(p)){
            lista_personas = Arrays.copyOf(lista_personas, lista_personas.length+1);
            lista_personas[lista_personas.length-1]=p;
        }
        return true;

    }

    public boolean removePersona(Persona p){
        Persona[] personas = new Persona[0];
        for (int i = 0; i < lista_personas.length; i++) {
            if (lista_personas[i]!=p){
                personas = Arrays.copyOf(personas, personas.length+1);
                personas[personas.length-1]=lista_personas[i];
            }
        }
        lista_personas=personas;
        return true;
    }

    public boolean esta(Persona p){
        for (int i = 0; i < lista_personas.length; i++) {
            if (lista_personas[i]==p){
                return true;
            }
        }
        return false;
    }
    @Override
    public String toString() {
        return "Vivienda{" +
                "numero_banios=" + numero_banios +
                ", n_habitaciones=" + n_habitaciones +
                ", cap_max=" + cap_max +
                ", precio=" + precio +
                ", lista_personas=" + Arrays.toString(lista_personas) + super.toString()+
                '}';
    }

    public String mostrarPropiedad(){
        return super.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Vivienda vivienda = (Vivienda) o;
        return Arrays.equals(lista_personas, vivienda.lista_personas);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(lista_personas);
    }

    @Override
    public int compareTo(Vivienda o) {
        return this.getN_habitaciones()-o.getN_habitaciones();
    }

    @Override
    public void mostrarPrecioVenta() {
        System.out.println("soy una vivienda y valgo"+getPrecio());
    }
}
