package U5.ENTREGABLE;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Persona p1 = new Persona("239839L", "Pepa Gallardo Solis");
        Persona p2 = new Persona("823984I", "Nati Lil Nati");
        Persona p3 = new Persona("238232L", "Carlos Matutino");
        Persona p4 = new Persona("839124I", "Natalia Rimel");
        Persona p5 = new Persona("239433A", "Popo Nieles");
        Persona p6 = new Persona("823923O", "Nuria Juerza");
        Persona p7 = new Persona("239835U", "Niewww Kiembe");
        Persona p8 = new Persona("839344J", "Maaestro Rosario");
        Vivienda v1 = new Vivienda(2018, "Avenida Chula", 58, 3, 6, 5, 209900);
        Vivienda v2 = new Vivienda(2008, "Calle los Alavas", 40, 4, 9, 8, 390000);
        Comercial c1 = new Comercial(2010,"Calle Maldivas", 36, p2, 434430,"Tienda de trenes");
        EquipamientoServicio e1 = new EquipamientoServicio(2007,"Calle trece", 20, Tipo.SANITARIO);
        Industrial i1 = new Industrial(2019, "El Campo", 290, p4, 423920,32443);

        v1.addPersona(p1);
        v1.addPersona(p2);
        v2.addPersona(p3);
        v2.addPersona(p4);
        v2.addPersona(p5);
        v2.addPersona(p6);
        v2.addPersona(p7);
        v2.addPersona(p8);

        Vivienda[] viviendas={v1, v2};
        Arrays.sort(viviendas);
        System.out.println(Arrays.toString(viviendas));

        Registro pueblo = new Registro();

        pueblo.addPropiedad(v1);
        pueblo.addPropiedad(v2);
        pueblo.addPropiedad(c1);
        pueblo.addPropiedad(e1);
        pueblo.addPropiedad(i1);

        System.out.println(Arrays.toString(v1.getLista_personas()));
        v1.removePersona(p1); //compruebo que se quitan bien
        System.out.println(Arrays.toString(v1.getLista_personas()));

        System.out.println(pueblo);
        System.out.println(Arrays.toString(pueblo.informeAntiguedad()));
        System.out.println(Arrays.toString(pueblo.informeSuperficie()));


        c1.mostrarPrecioVenta();
    }
}
