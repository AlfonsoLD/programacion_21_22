package U5.ENTREGABLE;

public abstract class Propiedad {
    private int fecha_construccion;
    private String direccion;
    private int metros;

    public Propiedad(int fecha_construccion, String direccion, int metros) {
        this.fecha_construccion = fecha_construccion;
        this.direccion = direccion;
        this.metros = metros;
    }

    public Propiedad() {

    }

    public int getFecha_construccion() {
        return fecha_construccion;
    }

    public void setFecha_construccion(int fecha_construccion) {
        this.fecha_construccion = fecha_construccion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getMetros() {
        return metros;
    }

    public void setMetros(int metros) {
        this.metros = metros;
    }

    @Override
    public String toString() {
        return "Propiedad{" +
                "fecha_construccion=" + fecha_construccion +
                ", direccion='" + direccion + '\'' +
                ", metros=" + metros +
                '}';
    }
}
