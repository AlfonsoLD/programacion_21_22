package U5.ENTREGABLE;

public interface mostrarPrecioVenta {
    void mostrarPrecioVenta();
}
