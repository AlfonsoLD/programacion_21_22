package U5.ENTREGABLE;

import java.util.Objects;

public class Persona {
    private String NIF;
    private String Nombre_Apellidos;
    private static int auto_increment;
    private int id;

    public Persona(String NIF, String nombre_Apellidos) {
        this.NIF = NIF;
        Nombre_Apellidos = nombre_Apellidos;
        this.id = auto_increment;
        auto_increment++;
    }

    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    public String getNombre_Apellidos() {
        return Nombre_Apellidos;
    }

    public void setNombre_Apellidos(String nombre_Apellidos) {
        Nombre_Apellidos = nombre_Apellidos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Persona persona = (Persona) o;
        return id == persona.id && NIF.equals(persona.NIF) && Nombre_Apellidos.equals(persona.Nombre_Apellidos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(NIF, Nombre_Apellidos, id);
    }

    @Override
    public String toString() {
        return "Persona{" +
                "NIF='" + NIF + '\'' +
                ", Nombre_Apellidos='" + Nombre_Apellidos + '\'' +
                ", id=" + id +
                '}';
    }
}
