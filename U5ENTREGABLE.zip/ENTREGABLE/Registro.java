package U5.ENTREGABLE;

import java.util.Arrays;
import java.util.Comparator;

public class Registro{
    private Propiedad[] lista_propiedades;

    public Registro() {
        lista_propiedades = new Propiedad[0];
    }

    public Propiedad[] getLista_propiedades() {
        return lista_propiedades;
    }

    public void setLista_propiedades(Propiedad[] lista_propiedades) {
        this.lista_propiedades = lista_propiedades;
    }

    @Override
    public String toString() {
        return "Registro{" +
                "lista_propiedades=" + Arrays.toString(lista_propiedades) +
                '}';
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(lista_propiedades);
    }
    public void addPropiedad(Propiedad propiedad){
            lista_propiedades = Arrays.copyOf(lista_propiedades, lista_propiedades.length+1);
            lista_propiedades[lista_propiedades.length-1]=propiedad;
    }

    public boolean removePropiedad(Propiedad propiedad){
        Propiedad[] propiedades = new Propiedad[0];
        if (esta(propiedad)) {
            for (int i = 0; i < lista_propiedades.length; i++) {
                if (lista_propiedades[i] != propiedad) {
                    propiedades = Arrays.copyOf(propiedades, propiedades.length + 1);
                    propiedades[propiedades.length - 1] = lista_propiedades[i];
                }
            }
            lista_propiedades = propiedades;
            return true;
        }
        return false;
    }

    public boolean esta(Propiedad propiedad) {
        for (int i = 0; i < lista_propiedades.length; i++) {
            if (lista_propiedades[i] == propiedad) {
                return true;
            }
        }
        return false;
    }

    public Propiedad[] informeSuperficie(){
    Arrays.sort(lista_propiedades, new Comparator<Propiedad>() {
        @Override
        public int compare(Propiedad o1, Propiedad o2) {
            return o1.getMetros()-o2.getMetros();
        }
    });
    return lista_propiedades;
    }
    public Propiedad[] informeAntiguedad(){
        Arrays.sort(lista_propiedades, new Comparator<Propiedad>() {
            @Override
            public int compare(Propiedad o1, Propiedad o2) {
                if (o2.getFecha_construccion()-o1.getFecha_construccion()!=0){
                return o2.getFecha_construccion()-o1.getFecha_construccion();
                }
                return o2.getMetros()-o1.getMetros();
            }
        });
        return lista_propiedades;
    }

}
