package U5.ENTREGABLE;

public class Industrial extends Local implements mostrarPrecioVenta{
    private double consumo;

    public Industrial(int fecha_construccion, String direccion, int metros, Persona duenio, double precio, double consumo) {
        super(fecha_construccion, direccion, metros, duenio, precio);
        this.consumo = consumo;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }

    @Override
    public String toString() {
        return "Industrial{" +
                "consumo=" + consumo +
                '}';
    }

    @Override
    public void mostrarPrecioVenta() {
        System.out.println("soy una vivienda y valgo"+getPrecio());
    }
}
