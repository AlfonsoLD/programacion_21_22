package U5.ENTREGABLE;

public abstract class Local extends Propiedad implements mostrarPrecioVenta{
    private Persona duenio;
    private double precio;

    public Local(int fecha_construccion, String direccion, int metros, Persona duenio, double precio) {
        super(fecha_construccion, direccion, metros);
        this.duenio = duenio;
        this.precio = precio;
    }

    public Persona getDuenio() {
        return duenio;
    }

    public void setDuenio(Persona duenio) {
        this.duenio = duenio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Local{" + super.toString()+
                "duenio=" + duenio +
                ", precio=" + precio +
                '}';
    }
}
