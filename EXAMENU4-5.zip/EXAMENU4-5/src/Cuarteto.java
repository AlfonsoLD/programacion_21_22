import java.util.Objects;

public class Cuarteto extends Agrupaciones {
private int n_miembros;

    public Cuarteto(String nombre, String autor, String autor_musica, String autor_letra, Disfraz disfraz, Double puntos, int n_miembros) {
        super(nombre, autor, autor_musica, autor_letra, disfraz, puntos);
        this.n_miembros = n_miembros;
    }

    public int getN_miembros() {
        return n_miembros;
    }

    public void setN_miembros(int n_miembros) {
        this.n_miembros = n_miembros;
    }

    @Override
    public String toString() {
        return "Cuarteto{" +super.toString()+
                "n_miembros=" + n_miembros +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Cuarteto cuarteto = (Cuarteto) o;
        return n_miembros == cuarteto.n_miembros;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), n_miembros);
    }
    @Override
    public void cantar_presentacion() {
        System.out.println("Cantando el Cuarteto con nombre "+getNombre());
    }

    @Override
    public void hacer_tipo() {
        System.out.println("El Cuarteto "+getNombre()+" va de "+getDisfraz());
    }
    @Override
    public void caminito_del_falla() {
        System.out.println("El cuarteto "+getNombre()+" va caminito del falla");
    }
}
