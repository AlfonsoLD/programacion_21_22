public enum Disfraz {buho, homosapiens, comida, locos, julian, benito

}
