import java.util.Objects;

public class Chirigota extends Agrupaciones{
    private int n_couples;

    public Chirigota(String nombre, String autor, String autor_musica, String autor_letra, Disfraz disfraz, Double puntos, int n_couples) {
        super(nombre, autor, autor_musica, autor_letra, disfraz, puntos);
        this.n_couples = n_couples;
    }

    public int getN_couples() {
        return n_couples;
    }

    public void setN_couples(int n_couples) {
        this.n_couples = n_couples;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Chirigota chirigota = (Chirigota) o;
        return n_couples == chirigota.n_couples;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), n_couples);
    }

    @Override
    public String toString() {
        return "Chirigota{" +super.toString()+
                "n_couples=" + n_couples +
                '}';
    }
    @Override
    public void cantar_presentacion() {
        System.out.println("Cantando la Chirigota con nombre "+getNombre());
    }

    @Override
    public void hacer_tipo() {
        System.out.println("La Chirigota "+getNombre()+" va de "+getDisfraz());
    }

    @Override
    public void caminito_del_falla() {
        System.out.println("La chirigota "+getNombre()+" va caminito del falla");
    }

}
