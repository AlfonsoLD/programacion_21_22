import java.util.Objects;

public class Comparsa extends Agrupaciones{
    private String empresa_atrezos;

    public Comparsa(String nombre, String autor, String autor_musica, String autor_letra, Disfraz disfraz, Double puntos, String empresa_atrezos) {
        super(nombre, autor, autor_musica, autor_letra, disfraz, puntos);
        this.empresa_atrezos = empresa_atrezos;
    }

    public String getEmpresa_atrezos() {
        return empresa_atrezos;
    }

    public void setEmpresa_atrezos(String empresa_atrezos) {
        this.empresa_atrezos = empresa_atrezos;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Comparsa comparsa = (Comparsa) o;
        return Objects.equals(empresa_atrezos, comparsa.empresa_atrezos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), empresa_atrezos);
    }

    @Override
    public String toString() {
        return "Comparsa{" +super.toString()+
                "empresa_atrezos='" + empresa_atrezos + '\'' +
                '}';
    }

    @Override
    public void cantar_presentacion() {
        System.out.println("Cantando la Comparsa con nombre "+getNombre());
    }

    @Override
    public void hacer_tipo() {
        System.out.println("La Comparsa "+getNombre()+" va de "+getDisfraz());
    }
    @Override
    public void caminito_del_falla() {
        System.out.println("La comparsa "+getNombre()+" va caminito del falla");
    }
}
