import java.util.Arrays;

public class COAC {
    private Agrupaciones[] agrupacionOficial;

    public Agrupaciones[] getAgrupacionOficial() {
        return agrupacionOficial;
    }

    public void setAgrupacionOficial(Agrupaciones[] agrupacionOficial) {
        this.agrupacionOficial = agrupacionOficial;
    }

    public COAC(Agrupaciones[] agrupacionOficial) {
        this.agrupacionOficial = agrupacionOficial;
    }

    public void inscribir_agrupacion(Agrupaciones a){
        agrupacionOficial = Arrays.copyOf(agrupacionOficial, agrupacionOficial.length+1);
        agrupacionOficial[agrupacionOficial.length-1]= a;

    }

    public boolean eliminar_agrugacion(Agrupaciones i1){
        Agrupaciones[] lista = new Agrupaciones[0];
        for (int i = 0; i < agrupacionOficial.length; i++) {
            if (agrupacionOficial[i]!=i1){
                lista = Arrays.copyOf(lista, lista.length+1);
                lista[lista.length-1]= agrupacionOficial[i];
            }
        }
        agrupacionOficial =lista;
        return true;
    }

    @Override
    public String toString() {
        return "COAC{" +
                "agrupacionOficial=" + Arrays.toString(agrupacionOficial) +
                '}';
    }
}
