public class Main {
    public static void main(String[] args) {

        Chirigota ch1= new Chirigota("JUANES", "JUAN", "PABLOO", "NADIEE", Disfraz.comida, 23.2, 2);
        Chirigota ch2= new Chirigota("Niii", "Zua", "POsa", "Vueu", Disfraz.locos, 43.2, 4);
        Comparsa co1= new Comparsa("LOOO", "SSS", "SSIOAJ", "WELLINTON", Disfraz.buho, 12.4, "almance");
        Coro cr1=new Coro("qe", "oqie", "d", "kaka", Disfraz.homosapiens, 32.4, 3, 3);
        Cuarteto cu1=new Cuarteto("JULIAN", "LULIAN", "KILIAN", "KULIAN", Disfraz.julian,387.2, 4);
        Romancero r1=new Romancero("Jsass", "ew", "adads", "wee", Disfraz.benito, 348.9, "Naabo");
        Integrante i1 = new Integrante(2, "aa", 34, "UM");

        r1.caminito_del_falla();
        r1.hacer_tipo();
        co1.cantar_presentacion();
        ch1.insertar_integrante(i1);
        ch1.quitar_integrante(i1);



    }
}
