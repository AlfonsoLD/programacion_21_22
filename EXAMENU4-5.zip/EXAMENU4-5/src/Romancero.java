import java.util.Objects;

public class Romancero extends Agrupaciones{
    private String tema_cartelon;

    public Romancero(String nombre, String autor, String autor_musica, String autor_letra, Disfraz disfraz, Double puntos, String tema_cartelon) {
        super(nombre, autor, autor_musica, autor_letra, disfraz, puntos);
        this.tema_cartelon = tema_cartelon;
    }

    public String getTema_cartelon() {
        return tema_cartelon;
    }

    public void setTema_cartelon(String tema_cartelon) {
        this.tema_cartelon = tema_cartelon;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Romancero romancero = (Romancero) o;
        return Objects.equals(tema_cartelon, romancero.tema_cartelon);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), tema_cartelon);
    }

    @Override
    public String toString() {
        return "Romancero{" +super.toString()+
                "tema_cartelon='" + tema_cartelon + '\'' +
                '}';
    }
    @Override
    public void cantar_presentacion() {
        System.out.println("Cantando el Romancero con nombre "+getNombre());
    }

    @Override
    public void hacer_tipo() {
        System.out.println("El Romancero "+getNombre()+" va de "+getDisfraz());
    }

    @Override
    public void caminito_del_falla() {
        System.out.println("El romancero "+getNombre()+" va caminito del falla");
    }
}
