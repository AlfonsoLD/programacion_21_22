import java.util.Objects;

public class Integrante {
    private int n_participante;
    private String nombre;
    private int edad;
    private String localidad;

    public Integrante(int n_participante, String nombre, int edad, String localidad) {
        this.n_participante = n_participante;
        this.nombre = nombre;
        this.edad = edad;
        this.localidad = localidad;
    }

    public int getN_participante() {
        return n_participante;
    }

    public void setN_participante(int n_participante) {
        this.n_participante = n_participante;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Integrante that = (Integrante) o;
        return n_participante == that.n_participante && edad == that.edad && Objects.equals(nombre, that.nombre) && Objects.equals(localidad, that.localidad);
    }

    @Override
    public int hashCode() {
        return Objects.hash(n_participante, nombre, edad, localidad);
    }

    @Override
    public String toString() {
        return "Integrante{" +
                "n_participante=" + n_participante +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", localidad='" + localidad + '\'' +
                '}';
    }
}
