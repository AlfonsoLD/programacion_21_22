import java.util.Arrays;
import java.util.Objects;

public abstract class Agrupaciones {
    private String nombre;
    private String autor;
    private String autor_musica;
    private String autor_letra;
    private Disfraz disfraz;
    private Double puntos;
    private Integrante[] integrantes;
    private int n_agrupaciones;

    public Integrante[] getIntegrantes() {
        return integrantes;
    }

    public void setIntegrantes(Integrante[] integrantes) {
        this.integrantes = integrantes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getAutor_musica() {
        return autor_musica;
    }

    public void setAutor_musica(String autor_musica) {
        this.autor_musica = autor_musica;
    }

    public String getAutor_letra() {
        return autor_letra;
    }

    public void setAutor_letra(String autor_letra) {
        this.autor_letra = autor_letra;
    }

    public Disfraz getDisfraz() {
        return disfraz;
    }

    public void setDisfraz(Disfraz disfraz) {
        this.disfraz = disfraz;
    }

    public Double getPuntos() {
        return puntos;
    }

    public void setPuntos(Double puntos) {
        this.puntos = puntos;
    }

    public Agrupaciones(String nombre, String autor, String autor_musica, String autor_letra, Disfraz disfraz, Double puntos) {
        this.nombre = nombre;
        this.autor = autor;
        this.autor_musica = autor_musica;
        this.autor_letra = autor_letra;
        this.disfraz = disfraz;
        this.puntos = puntos;
        n_agrupaciones++;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Agrupaciones that = (Agrupaciones) o;
        return Objects.equals(nombre, that.nombre) && Objects.equals(autor, that.autor) && Objects.equals(autor_musica, that.autor_musica) && Objects.equals(autor_letra, that.autor_letra) && disfraz == that.disfraz && Objects.equals(puntos, that.puntos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, autor, autor_musica, autor_letra, disfraz, puntos);
    }

    @Override
    public String toString() {
        return "Agrupaciones{" +
                "nombre='" + nombre + '\'' +
                ", autor='" + autor + '\'' +
                ", autor_musica='" + autor_musica + '\'' +
                ", autor_letra='" + autor_letra + '\'' +
                ", disfraz=" + disfraz +
                ", puntos=" + puntos +
                '}';
    }


    public void insertar_integrante(Integrante i){
                integrantes = Arrays.copyOf(integrantes, integrantes.length+1);
                integrantes[integrantes.length-1]=i;
    }

    public boolean quitar_integrante(Integrante i1){
            Integrante[] lista = new Integrante[0];
            for (int i = 0; i < integrantes.length; i++) {
                if (integrantes[i]!=i1){
                    lista = Arrays.copyOf(lista, lista.length+1);
                    lista[lista.length-1]= integrantes[i];
                }
            }
            integrantes =lista;
            return true;
    }
    public abstract void cantar_presentacion();

    public abstract void hacer_tipo();

    public abstract void caminito_del_falla();

}
