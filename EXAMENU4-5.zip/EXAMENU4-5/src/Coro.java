import java.util.Objects;

public class Coro extends Agrupaciones{
    private int n_bandurrias;
    private int n_guitarras;

    public Coro(String nombre, String autor, String autor_musica, String autor_letra, Disfraz disfraz, Double puntos, int n_bandurrias, int n_guitarras) {
        super(nombre, autor, autor_musica, autor_letra, disfraz, puntos);
        this.n_bandurrias = n_bandurrias;
        this.n_guitarras = n_guitarras;
    }

    public int getN_bandurrias() {
        return n_bandurrias;
    }

    public void setN_bandurrias(int n_bandurrias) {
        this.n_bandurrias = n_bandurrias;
    }

    public int getN_guitarras() {
        return n_guitarras;
    }

    public void setN_guitarras(int n_guitarras) {
        this.n_guitarras = n_guitarras;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Coro coro = (Coro) o;
        return n_bandurrias == coro.n_bandurrias && n_guitarras == coro.n_guitarras;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), n_bandurrias, n_guitarras);
    }

    @Override
    public String toString() {
        return "Coro{" +super.toString()+
                "n_bandurrias=" + n_bandurrias +
                ", n_guitarras=" + n_guitarras +
                '}';
    }
    @Override
    public void cantar_presentacion() {
        System.out.println("Cantando el Coro con nombre "+getNombre());
    }

    @Override
    public void hacer_tipo() {
        System.out.println("El Coro "+getNombre()+" va de "+getDisfraz());
    }
    @Override
    public void caminito_del_falla() {
        System.out.println("El coro "+getNombre()+" va caminito del falla");
    }
}
