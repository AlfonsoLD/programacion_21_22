public enum Interfaz {
    BLUETOOTH, IR, JACK
}
