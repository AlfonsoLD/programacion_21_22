public interface RevisionPrecio {
    int compare(Revision r1, Revision r2);
}
