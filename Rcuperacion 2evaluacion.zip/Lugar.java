public enum Lugar {Puerta,Salpicadero
}
