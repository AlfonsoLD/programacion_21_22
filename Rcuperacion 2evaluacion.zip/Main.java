import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
    BANGANDALUFSEN registro = new BANGANDALUFSEN(new Altavoz[0]);

    AltavozTV a1 = new AltavozTV(1, 13,15,new Revision[0], Interfaz.BLUETOOTH);
    AltavozCoche a2 = new AltavozCoche(2,12,34, new Revision[0], TipoCoche.AltavozEmpotrado, Lugar.Puerta);
    AltavozCoche a3 = new AltavozCoche(3,32,34, new Revision[0], TipoCoche.AltavozEmpotrado, Lugar.Salpicadero);
    AltavozMovil a4 = new AltavozMovil(4, 3, 10,new Revision[0], 712);

    Revision r1 = new Revision("2nov", true, 317);
    Revision r2 = new Revision("4nov", false, 327);
    Revision r3 = new Revision("1mar", true, 517);
    Revision r4 = new Revision("2abr", true, 891);
    Revision r5 = new Revision("19may", true, 313);
    Revision r6 = new Revision("13nov", false, 217);
    Revision r7 = new Revision("10ene", true, 517);
    Revision r8 = new Revision("29dic", true, 391);

    registro.addAltavoz(a1);
    registro.addAltavoz(a2);
    registro.addAltavoz(a3);
    registro.addAltavoz(a4);

    a1.addReview(r1);
    a1.addReview(r2);
    a2.addReview(r3);
    a2.addReview(r4);
    a3.addReview(r5);
    a3.addReview(r6);
    a4.addReview(r7);
    a4.addReview(r8);



    registro.delReview(1,r2);
    System.out.println(Arrays.toString(a1.getRevisiones()));

    registro.removeAltavoz(2);
    registro.mostrarRevisiones(4);
    registro.mostrarporAltura();

    }

}
