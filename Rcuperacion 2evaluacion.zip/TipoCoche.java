public enum TipoCoche {
    AltavozEmpotrado, AltavozTrasero
}
