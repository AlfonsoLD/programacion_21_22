import java.util.Objects;

public class Revision implements RevisionPrecio {
    private String fecha;
    private boolean buen_estado;
    private int precio_visita;

    public Revision(String fecha, boolean buen_estado, int precio_visita) {
        this.fecha = fecha;
        this.buen_estado = buen_estado;
        this.precio_visita = precio_visita;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public boolean isBuen_estado() {
        return buen_estado;
    }

    public void setBuen_estado(boolean buen_estado) {
        this.buen_estado = buen_estado;
    }

    public int getPrecio_visita() {
        return precio_visita;
    }

    public void setPrecio_visita(int precio_visita) {
        this.precio_visita = precio_visita;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Revision revision = (Revision) o;
        return buen_estado == revision.buen_estado && Double.compare(revision.precio_visita, precio_visita) == 0 && Objects.equals(fecha, revision.fecha);
    }

    @Override
    public int hashCode() {
        return Objects.hash(fecha, buen_estado, precio_visita);
    }

    @Override
    public int compare(Revision r1, Revision r2) {
            return r1.getPrecio_visita()-r2.getPrecio_visita();
    }

    @Override
    public String toString() {
        return "Revision{" +
                "fecha='" + fecha + '\'' +
                ", buen_estado=" + buen_estado +
                ", precio_visita=" + precio_visita +
                '}';
    }
}
