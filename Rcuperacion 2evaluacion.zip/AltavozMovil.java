import java.util.Arrays;

public class AltavozMovil extends Altavoz{
    private int peso;

    public AltavozMovil(int num_serie, int altura, int anchura, Revision[] revisiones, int peso) {
        super(num_serie, altura, anchura, revisiones);
        this.peso = peso;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "AltavozMovil{" +
                "num_serie=" + num_serie +
                ", altura=" + altura +
                ", anchura=" + anchura +
                ", revisiones=" + Arrays.toString(revisiones) +
                ", peso=" + peso +
                '}';
    }
}
