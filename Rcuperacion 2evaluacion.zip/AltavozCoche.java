import java.util.Arrays;
public class AltavozCoche extends Altavoz implements Grave{
    private TipoCoche tipo;
    private Lugar lugar;

    private int potencia;
    private boolean decoracionLed;

    public AltavozCoche(int num_serie, int altura, int anchura, Revision[] revisiones, TipoCoche tipo, Lugar lugar) {
        super(num_serie, altura, anchura, revisiones);
        this.tipo = tipo;
        this.lugar = lugar;
        if (this.tipo == TipoCoche.AltavozTrasero) {
            this.potencia = potencia;
            this.decoracionLed = decoracionLed;
        }
    }



    public TipoCoche getTipo() {
        return tipo;
    }

    public void setTipo(TipoCoche tipo) {
        this.tipo = tipo;
    }

    public Lugar getLugar() {
        return lugar;
    }

    public void setLugar(Lugar lugar) {
        this.lugar = lugar;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public boolean isDecoracionLed() {
        return decoracionLed;
    }

    public void setDecoracionLed(boolean decoracionLed) {
        this.decoracionLed = decoracionLed;
    }

    @Override
    public String toString() {
        return "AltavozCoche{" +
                "num_serie=" + num_serie +
                ", altura=" + altura +
                ", anchura=" + anchura +
                ", revisiones=" + Arrays.toString(revisiones) +
                ", tipo=" + tipo +
                ", lugar=" + lugar +
                ", potencia=" + potencia +
                ", decoracionLed=" + decoracionLed +
                '}';
    }

    @Override
    public void activarGraves() {
        if (this.tipo == TipoCoche.AltavozTrasero) {
            System.out.println("Los graves de su altavoz trasero han sido activados");
        }
        else {
            System.out.println("Los graves de su altavoz empotrado han sido activados");
        }
    }
}
