public interface Comparadoraltura {
    public static int Compararprecio(Altavoz a1, Altavoz a2){
        return a1.getAltura()- a2.getAltura();
    }
}
