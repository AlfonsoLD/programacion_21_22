import java.util.Arrays;
import java.util.Objects;

public abstract class Altavoz implements Comparadoraltura {
    protected int num_serie;
    protected int altura;
    protected int anchura;
    protected Revision[] revisiones;

    public int getNumeroaltavoces() {
        return numeroaltavoces;
    }

    public void setNumeroaltavoces(int numeroaltavoces) {
        this.numeroaltavoces = numeroaltavoces;
    }

    private int numeroaltavoces =0;

    public Altavoz(int num_serie, int altura, int anchura, Revision[] revisiones) {
        this.num_serie = num_serie;
        this.altura = altura;
        this.anchura = anchura;
        this.revisiones = revisiones;

        numeroaltavoces++;
    }

    public int getNum_serie() {
        return num_serie;
    }

    public void setNum_serie(int num_serie) {
        this.num_serie = num_serie;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getAnchura() {
        return anchura;
    }

    public void setAnchura(int anchura) {
        this.anchura = anchura;
    }

    public Revision[] getRevisiones() {
        return revisiones;
    }

    public void setRevisiones(Revision[] revisiones) {
        this.revisiones = revisiones;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Altavoz altavoz = (Altavoz) o;
        return num_serie == altavoz.num_serie && altura == altavoz.altura && anchura == altavoz.anchura && Arrays.equals(revisiones, altavoz.revisiones);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(num_serie, altura, anchura);
        result = 31 * result + Arrays.hashCode(revisiones);
        return result;
    }

    @Override
    public String toString() {
        return "Altavoz{" +
                "num_serie=" + num_serie +
                ", altura=" + altura +
                ", anchura=" + anchura +
                ", revisiones=" + Arrays.toString(revisiones) +
                '}';
    }

    public boolean addReview(Revision rev){
        for (int i = 0; i < revisiones.length; i++) {
            if (revisiones[i].getFecha().equals(rev.getFecha())){
                return false;
            }
        }
        revisiones = Arrays.copyOf(revisiones, revisiones.length+1);
        revisiones[revisiones.length-1]=rev;
        return true;
    }
    public int numeroAltavoces(){
        return numeroaltavoces;
    }
}
