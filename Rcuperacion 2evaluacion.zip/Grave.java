public interface Grave {
    public void activarGraves();
}
