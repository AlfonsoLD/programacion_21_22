import java.util.Arrays;

public class BANGANDALUFSEN {
    private Altavoz[] registro;
    public BANGANDALUFSEN(Altavoz[] registro) {
        this.registro = registro;
    }
    public Altavoz[] getRegistro() {
        return registro;
    }

    public void setRegistro(Altavoz[] registro) {
        this.registro = registro;
    }
    public boolean addAltavoz(Altavoz at){
        for (int i = 0; i < registro.length; i++) {
            if (registro[i].getNum_serie()==at.getNum_serie()){
                return false;
            }
        }
        registro = Arrays.copyOf(registro, getRegistro().length+1);
        registro[getRegistro().length-1]=at;
        return true;
    }
    public boolean removeAltavoz(int numserie){
        Altavoz[] registronew = new Altavoz[0];
        int j =0;
        for (int i = 0; i < registro.length; i++) {
            if (registro[i].getNum_serie()!=numserie){
                registronew = Arrays.copyOf(registronew, registronew.length+1);
                registronew[j]=registro[j];
                j++;
            }
        }
        if (registro!=registronew){
            registro=registronew;
            return true;
        }
        return false;
    }
    public boolean delReview (int numserie, Revision revision){
        Revision[] revisionesnew = new Revision[0];
        int j = 0;
        for (int i = 0; i < getRegistro().length; i++) {
            if (registro[i].getNum_serie()==numserie){
                for (int k = 0; k < registro[i].getRevisiones().length; k++) {
                    if (registro[i].getRevisiones()[i]!=revision){
                        revisionesnew = Arrays.copyOf(revisionesnew, revisionesnew.length+1);
                        revisionesnew[j]=registro[i].getRevisiones()[j];
                        j++;
                    }
                }
                if (registro[i].getRevisiones()!=revisionesnew){
                registro[i].setRevisiones(revisionesnew);
                    return true;
                }
            }
        }
        return false;
    }
    public void mostrarRevisiones(int numserie){
        boolean existe = false;
        for (int i = 0; i < getRegistro().length; i++) {
            if (registro[i].getNum_serie()==numserie){
                System.out.println(Arrays.toString(registro[i].getRevisiones()));
                existe=true;
            }
        }
        if (!existe){
        System.out.println("Altavoz no existe");}
    }

    public void mostrarporAltura (){
        System.out.println(Arrays.toString(getRegistro()));
    }
}
