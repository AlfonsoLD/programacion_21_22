import java.util.Arrays;

public class AltavozTV extends Altavoz{
    private Interfaz tipo;

    public AltavozTV(int num_serie, int altura, int anchura, Revision[] revisiones, Interfaz tipo) {
        super(num_serie, altura, anchura, revisiones);
        this.tipo = tipo;
    }

    public Interfaz getTipo() {
        return tipo;
    }

    public void setTipo(Interfaz tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "AltavozTV{" +
                "num_serie=" + num_serie +
                ", altura=" + altura +
                ", anchura=" + anchura +
                ", revisiones=" + Arrays.toString(revisiones) +
                ", tipo=" + tipo +
                '}';
    }
}
