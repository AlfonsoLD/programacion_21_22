import java.util.Scanner;

public class EJ1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura = 0;
        while (altura<=3) {
            System.out.println("Introduce la altura de la piramide");
            altura = sc.nextInt();
        }
        for (int i =0; i< altura*2; i++) {
            for(int j = 0; j < altura*3; j++) {
                if(i==altura*2-1 & i==j+1|| i==altura*2-3 || i==altura*2-5){
                    System.out.print(" ");
                }
                else {
                    System.out.print("*");
                }
            }
            System.out.println();
        }






    }
}
