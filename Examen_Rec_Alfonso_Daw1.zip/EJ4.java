import java.util.Arrays;
import java.util.Scanner;

public class EJ4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("pon la dimension de la matriz");
        int dimension = sc.nextInt();
        int[][] a = new int[dimension][dimension];

        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                a[i][j] = (int) (100 + Math.random() * 101);
            }
        }
        for (int[] row : a) {
            System.out.println(Arrays.toString(row));
        }

        System.out.println("Numero de celdas adyacentes: " + Adyacentes(a));
    }


    static int Adyacentes(int[][] a) {
        int numerodeadyacentes=0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (i - 1 >= 0 & i + 1 < a.length & j - 1 >= 0 & j + 1 < a[i].length) {


                    if (a[i][j] >= a[i + 1][j + 1] & a[i][j] >= a[i][j + 1] & a[i][j] >= a[i + 1][j] &
                            a[i][j] >= a[i - 1][j - 1]
                            & a[i][j] >= a[i][j - 1] & a[i][j] >= a[i - 1][j] &
                            a[i][j] >= a[i - 1][j + 1] & a[i][j] >= a[i + 1][j - 1]) {
                     numerodeadyacentes++;
                    }
                }
            }
        }
        return numerodeadyacentes;
    }
}
