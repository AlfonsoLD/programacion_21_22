import java.util.Arrays;
import java.util.Scanner;

public class EJ5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("introduce una palabra");
        String palabra = sc.nextLine();

        System.out.println(Arrays.toString(Invertir(palabra)));
        System.out.println(Arrays.toString(DesplazarVocales(palabra)));

    }

    static String[] Invertir (String a){
        String mayus = a.toUpperCase();

        String[] decadena=new String[a.length()];
    String[]invertida=new String[a.length()];
        for (int i = 0; i < decadena.length; i++) {
            decadena[i]= String.valueOf(mayus.charAt(i));
        }
        for (int i = 0; i < decadena.length; i++) {
            invertida[i]=decadena[decadena.length-1-i];
        }
    return invertida;
    }
    static String[] DesplazarVocales (String a){
        String[] decadena=new String[a.length()];
        String[] desplazada =new String[a.length()];
        for (int i = 0; i < decadena.length; i++) {
            decadena[i]= String.valueOf(a.charAt(i));
        }
        for (int i = 0; i < decadena.length; i++) {

            if (decadena[i].equals("a")|| decadena[i].equals("e")||decadena[i].equals("i")|| decadena[i].equals("o")
            ||decadena[i].equals("u")) {
                switch (decadena[i]) {
                    case "a" -> desplazada[i] = "e";
                    case "e" -> desplazada[i] = "i";
                    case "i" -> desplazada[i] = "o";
                    case "o" -> desplazada[i] = "u";
                    case "u" -> desplazada[i] = "a";
                }
            }
            else {
                desplazada[i]=decadena[i];
            }
        }
        return desplazada;
    }
}
