import java.util.Arrays;
import java.util.Scanner;

public class EJ3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("pon el tamaño del primer vector");
        int sizea = sc.nextInt();
        System.out.println("pon los valores de a");
        int[] a = new int[sizea];
        for (int i = 0; i < sizea; i++) {
            a[i] = sc.nextInt();
            System.out.println("otro");
        }
        System.out.println("pon el tamaño del segundo vector");
        int sizeb = sc.nextInt();
        int[] b = new int[sizeb];
        System.out.println("pon los valores de b");
        for (int i = 0; i < sizeb; i++) {
            b[i] = sc.nextInt();
            System.out.println("otro");
        }
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(b));
        System.out.println(Arrays.toString(minimoVectores(a, b)));
    }

    public static int[] minimoVectores(int[] a, int[] b) {
        int[] resultado;
        int dif;
        if (a.length > b.length) {
            resultado = new int[a.length];
            dif = a.length - b.length;
        } else {
            resultado = new int[b.length];
            dif = b.length - a.length;
        }

        for (int i = 0; i < resultado.length - dif; i++) {
            resultado[i] = Math.min(a[i], b[i]);
        }

        for (int i = 0; i < dif; i++) {
            if (a.length > b.length) {
                resultado[resultado.length - dif + i] = a[a.length - dif + i];
            } else {
                resultado[resultado.length - dif + i] = b[b.length - dif + i];
            }
        }

        return resultado;
    }
}
