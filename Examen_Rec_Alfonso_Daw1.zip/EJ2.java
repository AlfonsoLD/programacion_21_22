import java.util.Scanner;

public class EJ2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("introduce un numero");
        long num = sc.nextLong();
        System.out.println("introduce la posicion del numero a cambiar");
        int pos = sc.nextInt();
        System.out.println("Introduce el numero por el que desea cambiarlo");
        int nuevonum = sc.nextInt();
        String cadena = "";
        String resultado = "";

        cadena += num;


        for (int i = 0; i < cadena.length(); i++) {
            if (i != pos - 1) {
                resultado += cadena.charAt(i);
            } else {
                resultado += nuevonum;
            }
        }

        System.out.println(resultado);
    }
}
