import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Transacciones {
    public static void Cliente(){
        Connection con = ConexionBD.getConnection();

        try{
            con.setAutoCommit(false);
            PreparedStatement ps1 = con.prepareStatement("INSERT INTO customers \n" +
                    "VALUES (500, 'nUEVOO', 'MI PRIMA', 'PARE', '12093', 'CIELO', NULL, 'Sevilla', NULL, NULL, 'USA', 1612, 1920);");
            System.out.println(ps1.executeUpdate());
            con.commit();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void Oficina(){
        Connection con = ConexionBD.getConnection();

        try{
            con.setAutoCommit(false);
            PreparedStatement ps2 = con.prepareStatement("INSERT INTO offices \n" +
                    "VALUES (8, 'Tokyo', '44121081223', 'La gente fuerte', 'Sunami', 'Cali', 'Japan', 'cODIOG23', 'Japan');");
            System.out.println(ps2.executeUpdate());
            con.commit();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }



    }
}
