import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Consultas {
    public static void empleadosOficinaMayor(){
        Connection con = ConexionBD.getConnection();

        try{
            PreparedStatement preparedStatement = con.prepareStatement("SELECT e.officeCode , COUNT(*) as total \n" +
                    "FROM employees e\n" +
                    "group by e.officeCode \n" +
                    "ORDER by total DESC\n" +
                    "LIMIT 1;");

            ResultSet rs = preparedStatement.executeQuery();
            int total = 0;
            while (rs.next()){
                total = rs.getInt(2);
            }
            System.out.println(total);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void productosNoVendidos (){
        Connection con = ConexionBD.getConnection();

        try {
            PreparedStatement ps = con.prepareStatement("SELECT p*\n" +
                    "FROM products p \n" +
                    "WHERE p.productCode  not in (SELECT o.productCode  FROM orderdetails o);");
            ResultSet rs = ps.executeQuery();

                System.out.println(rs.toString());


        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }
}

