public class Main {
    public static void main(String[] args) {

       // Transacciones.Cliente();
       // Transacciones.Oficina();
        Consultas.empleadosOficinaMayor();
       //Consultas.productosNoVendidos();

    }
}
