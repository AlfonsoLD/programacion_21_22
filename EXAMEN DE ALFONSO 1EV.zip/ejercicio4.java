import java.util.Arrays;
import java.util.Scanner;

public class ejercicio4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("pon la frase");
        String frase = sc.nextLine();


        for (String[]row:matrizLetras(frase)) System.out.println(Arrays.toString(row));

    }
    public static String[][]matrizLetras(String frase){
        String[][]matriz= new String[frase.length()/5][5];
        int posicion=0;
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (!String.valueOf(frase.charAt(posicion)).equals(" "))
                matriz[i][j] = String.valueOf(frase.charAt(posicion));
                posicion++;
            }

        }
        return matriz;
    }
}
