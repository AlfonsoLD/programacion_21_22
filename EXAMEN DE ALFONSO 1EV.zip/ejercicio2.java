import java.util.Arrays;

public class ejercicio2 {
    public static void main(String[] args) {

        int[]a = {1,4,5,7,9,1,5,6,19,32};

        System.out.println(hayduplicados(a));
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(eliminaDuplicados(a)));

    }

    public static boolean esta (int[]a, int num){

        for (int j : a) {
            if (j == num) {
                return true;
            }
        }
        return false;
    }

    public static boolean hayduplicados (int[]a){
        Arrays.sort(a); //los ordeno y los comparo con el de su derecha, si hubiera duplicados estarían al lado

        for (int i = 0; i < a.length; i++) {
           if (a[i]==a[i+1]) {
               return true;
           }
        }
        return false;
    }

    public static int[] eliminaDuplicados (int[]a){
        int[]resultado=new int[0];

        for (int j : a) {
            if (!esta(resultado, j)) {
                resultado = Arrays.copyOf(resultado, resultado.length + 1);
                resultado[resultado.length - 1] = j;
            }
        }
        return resultado;
    }

}
