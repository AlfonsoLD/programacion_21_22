import java.util.Arrays;
import java.util.Scanner;

public class ejercicio1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ponga el tamaño del array");
        int dimension=sc.nextInt();
        int[]a = new int[dimension];

        for (int i = 0; i < a.length; i++) {
            a[i]=(int) (18+Math.random()*65);
        }

        System.out.println(Arrays.toString(paresImpares(a)));


    }

    public static boolean esta (int[]a, int num){

        for (int j : a) {
            if (j == num) {
                return true;
            }
        }
        return false;
    }

    public static int[] paresImpares (int[]a){
        int[]resultado=new int[0];

        for (int i = 0; i < a.length; i++) {
            if (a[i]%2==0){

                resultado= Arrays.copyOf(resultado, resultado.length+1);
                resultado[resultado.length-1]=a[i];
            }
        }

        for (int i = 0; i < a.length; i++) {
            if (!esta(resultado, a[i])){
                resultado= Arrays.copyOf(resultado, resultado.length+1);
                resultado[resultado.length-1]=a[i];
            }
        }
        return resultado;
    }
}
