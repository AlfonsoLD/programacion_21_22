import java.util.Arrays;

public class ejercicio3 {
    public static void main(String[] args) {

        int[][]cuadrado = new int[4][4];
        for (int i = 0; i < cuadrado.length; i++) {
            for (int j = 0; j < cuadrado[i].length; j++) {
                cuadrado[i][j]=(int) (Math.random()*10);
            }
        }
        System.out.println(Arrays.deepToString(cuadrado));
        System.out.println(cuadradoMagico(cuadrado));
        //ahora creamos uno magico
        int[][]magico= new int[4][4];
        for (int i = 0; i < magico.length; i++) {
            for (int j = 0; j < magico[i].length; j++) {
                magico[i][j]=3;
            }
        }
        System.out.println(Arrays.deepToString(magico));
        System.out.println(cuadradoMagico(magico));

    }
    public static boolean cuadradoMagico (int[][]a){
        int sumaini=0;
        int sumafin=0;

            for (int j = 0; j < a.length; j++) {
                sumaini+=a[0][j];
            }

            for (int i = 1; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                sumafin+=a[i][j];
            }
            if (sumaini!=sumafin){
                return false;
            }
            else {
                sumafin=0;
            }
        }
    return true;
    }
}