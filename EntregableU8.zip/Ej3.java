import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Ej3 {
    public static void main(String[] args) {
        XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
        try{
            XMLEventReader xmlReader = xmlInputFactory.createXMLEventReader(new FileInputStream("alumnos.xml"));
int totalAlumnos = 0;
int alumnosEnDireccion = 0;
boolean estadireccion = false;
            Scanner sc = new Scanner(System.in);
            System.out.println("introduce una direccion");
            String direccion = sc.nextLine();

            while (xmlReader.hasNext()){
                XMLEvent xmlEvent = xmlReader.nextEvent();

                if (xmlEvent.isStartElement()){
                    StartElement startElement = xmlEvent.asStartElement();

                    if (startElement.getName().getLocalPart().equals("alumno")){
                        totalAlumnos++;
                    } else if (startElement.getName().getLocalPart().equals("direccion")) {
                      estadireccion = true;
                    } else if (xmlEvent.isCharacters()) {
                        Characters characters = xmlEvent.asCharacters();
                        if ( estadireccion && characters.getData().equals(direccion)){
                            alumnosEnDireccion++;
                            estadireccion=false;
                        }

                    }
                }
            }
            System.out.println("Numero total de alumnos"+totalAlumnos);
            System.out.println("Numero de alumnos en esa direccion"+alumnosEnDireccion);


        } catch (XMLStreamException | FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

}
