package U4.Tarea1.Entregable2122;

import java.util.Arrays;
import java.util.Calendar;

public class Examen {
    private Calendar.Builder fecha;
    private String Consejeria;
    private String URL;
    private Preguntas[] preguntas;
    final private int max_preguntas=100;

    public Examen(String consejeria, String URL) {
        Consejeria = consejeria;
        this.URL = URL;
        fecha.build();
    }

    public boolean Addpregunta(Preguntas preguntas1) {
        if (preguntas.length<max_preguntas) {
            preguntas = Arrays.copyOf(preguntas, preguntas.length + 1);
            for (int i = 0; i < preguntas.length; i++) {
                if (preguntas[i] == null) {
                    preguntas[i] = preguntas1;
                    break;
                }
            }
            return true;
        }
       return false;
    }

    public boolean delete_pregunta (Preguntas preguntas1) {
        for (int i = 0; i < preguntas.length; i++) {
            if (preguntas1.equals(preguntas[i])) {
                preguntas[i]=null;
            }
        }
        return true;
    }








    @Override
    public String toString() {
        return "Examen{" +
                "fecha=" + fecha +
                ", Consejeria='" + Consejeria + '\'' +
                ", URL='" + URL + '\'' +
                '}';
    }

    public boolean mostrar_informacionexamen(){
        System.out.println(toString());
        return true;
    }
}

