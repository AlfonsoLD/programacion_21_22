package U4.Tarea1.Entregable2122;

public class Opcion {
    private String texto;
    private boolean acierto;

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public boolean isAcierto() {
        return acierto;
    }

    public void setAcierto(boolean acierto) {
        this.acierto = acierto;
    }

    public Opcion(String texto, boolean acierto) {
        this.texto = texto;
        this.acierto = acierto;
    }

    public boolean mostrar_infoOpcion(){
        System.out.println(toString());
        return true;
    }

    @Override
    public String toString() {
        return "Opcion{" +
                "texto='" + texto + '\'' +
                ", acierto=" + acierto +
                '}';
    }
}
