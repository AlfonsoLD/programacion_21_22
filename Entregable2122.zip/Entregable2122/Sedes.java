package U4.Tarea1.Entregable2122;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Stream;

public class Sedes {
    private String cod_sede;
    private Ciudades_capitales ciudad;
    private Opositor[] opositores;

    public Sedes(String cod_sede, Ciudades_capitales ciudad) {
        this.cod_sede = cod_sede;
        this.ciudad = ciudad;
        this.opositores = new Opositor[0];

    }

    public boolean Addopositor(Opositor opositor) {
            opositores=Arrays.copyOf(opositores, opositores.length+1);
            for (int i = 0; i < opositores.length; i++) {
                if (opositores[i] == null) {
                    opositores[i]=opositor;
                    break;
                }
            }
        return true;
        }

        public boolean delete_opositor (Opositor opositor) {
        for (int i = 0; i < opositores.length; i++) {
            if (opositor.equals(opositores[i])) {
                opositores[i]=null;
            }
        }
        return true;
        }


    @Override
    public String toString() {
        return "Sedes{" +
                "cod_sede='" + cod_sede + '\'' +
                ", ciudad=" + ciudad +
                ", opositores=" + Arrays.toString(opositores) +
                '}';
    }
}

