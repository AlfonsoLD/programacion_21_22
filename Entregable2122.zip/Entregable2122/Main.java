package U4.Tarea1.Entregable2122;

public class Main {
    public static void main(String[] args) {

    Opositor o1 = new Opositor("Alfonso", "Lopez Diaz", 2001, false, null);
    Opositor o2 = new Opositor("Paco", "Perez Montana", 2003, true, "me cago aveces");
    Opositor o3 = new Opositor("Alaba", "Carrasco Buum", 2000, false, null);
    Opositor o4 = new Opositor("Jilguero", "Lara Nieto", 2007, true, "no se que me pasa no puedo");
    Sedes s1 = new Sedes("10010", Ciudades_capitales.CADIZ);
    Sedes s2 = new Sedes("489348", Ciudades_capitales.SEVILLA);
    Examen e1 = new Examen("Mairena", "www.examen.com");

    //creo las preguntas
    Preguntas p1 = new Preguntas("Cuantos dedos tengo");
    Opcion opcion1a=new Opcion("no lo se", false);
    Opcion opcion1b=new Opcion("Muchos", false);
    Opcion opcion1c=new Opcion("10 en total", true);
    p1.Addopcion(opcion1a);
    p1.Addopcion(opcion1b);
    p1.Addopcion(opcion1c);

    Preguntas p2 = new Preguntas("cuantas manos tengo");
    Opcion opcion2a=new Opcion("Si las cortas es posible que no te queden", true);
    Opcion opcion2b=new Opcion("2, siempre son 2", false);
    Opcion opcion2c=new Opcion("no lo se", false);
    p2.Addopcion(opcion2a);
    p2.Addopcion(opcion2b);
    p2.Addopcion(opcion2c);



    //las añado al examen
    e1.Addpregunta(p1);
    e1.Addpregunta(p2);

        System.out.println(o1);
        System.out.println(o2);
        System.out.println(o3);
        System.out.println(o4);
        System.out.println(Opositor.getContadorinscritos());
        System.out.println(Opositor.getNum_adaptados());
        //saco los opositores y el numero de inscritos y adaptados, luego saco las sedes
        System.out.println(s1);
        System.out.println(s2);
        //añado opositores a las sedes
        s1.Addopositor(o1);
        s2.Addopositor(o2);
        s1.Addopositor(o3);
        s2.Addopositor(o4);
        System.out.println(s1);
        System.out.println(s2);
        //quito dos opositores
        s1.delete_opositor(o1);
        s2.delete_opositor(o2);
        System.out.println(s1);
        System.out.println(s2);

    }
}
