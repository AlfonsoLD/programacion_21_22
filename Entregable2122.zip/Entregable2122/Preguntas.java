package U4.Tarea1.Entregable2122;

import java.util.Arrays;

public class Preguntas {
    private String enunciado;
    private Opcion[] opciones;
    private int max_op;

    public Preguntas(String enunciado) {
        this.enunciado = enunciado;
        this.max_op=3;
        this.opciones=new Opcion[3];
    }

    public boolean Addopcion(Opcion opcion) {
        opciones= Arrays.copyOf(opciones, opciones.length+1);
        for (int i = 0; i < opciones.length; i++) {
            if (opciones[i] == null) {
                opciones[i]=opcion;
                break;
            }
        }
        return true;
    }

    public boolean delete_opcion (Opcion opcion) {
        for (int i = 0; i < opciones.length; i++) {
            if (opcion.equals(opciones[i])) {
                opciones[i]=null;
            }
        }
        return true;
    }

    public boolean mostrar_infoPregunta(){
        System.out.println(toString());
        return true;
    }



    @Override
    public String toString() {
        return "Preguntas{" +
                "enunciado='" + enunciado + '\'' +
                ", opciones=" + Arrays.toString(opciones) +
                ", max_op=" + max_op +
                '}';
    }
}
