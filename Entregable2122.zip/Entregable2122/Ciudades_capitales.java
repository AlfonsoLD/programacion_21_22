package U4.Tarea1.Entregable2122;

public enum Ciudades_capitales {
    SEVILLA, HUELVA, CADIZ, GRANADA, MALAGA, JAEN, ALMERIA, CORDOBA
}
