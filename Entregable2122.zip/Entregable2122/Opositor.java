package U4.Tarea1.Entregable2122;

import U4.Tarea1.Casa.Bombilla;

public class Opositor {
    private static int contadorinscritos;
    private static int num_adaptados;
    private String nombre;
    private String apellidos;
    private Integer fecha_nac;
    private Boolean adaptacion;
    private String descripcion;
    public Opositor(String nombre, String apellidos, Integer fecha_nac, Boolean adaptacion, String descripcion) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fecha_nac = fecha_nac;
        this.adaptacion=adaptacion;
        if (adaptacion.equals(true)){
            this.descripcion = descripcion;
            num_adaptados++;
        }
        else {
            this.descripcion = null;
        }
        contadorinscritos++;
    }

    public static int getContadorinscritos() {
        return contadorinscritos;
    }

    public static int getNum_adaptados() {
        return num_adaptados;
    }

    public boolean mostrar_informacion(){
        System.out.println(toString());
        return true;
    }


    @Override
    public String toString() {
        return "Opositor{" +
                "nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", fecha_nac=" + fecha_nac +
                ", adaptacion=" + adaptacion +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }

}
